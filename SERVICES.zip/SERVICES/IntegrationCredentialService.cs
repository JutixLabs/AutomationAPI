﻿using AutomationAPI.DATA;
using AutomationAPI.MODEL.Entity;
using AutomationAPI.MODEL.Interface;
using Microsoft.EntityFrameworkCore;

namespace AutomationAPI.SERVICES
{
    public class IntegrationCredentialService : IIntegrationCredentialService
    {
        private readonly AppDbContext _dbContext;
        private readonly ISecretProtector _secretProtector;
        public IntegrationCredentialService(AppDbContext dbContext, ISecretProtector secretProtector)
        {
            _dbContext = dbContext;
            _secretProtector = secretProtector;
        }

        public Task<bool> ExistsAsync(string provider)
        {
            return _dbContext.IntegrationCredentials.AnyAsync(x => x.Provider == provider && x.IsActive);
        }

        public async Task<string> GetCredentialAsync(string provider)
        {
            var credentials = await _dbContext.IntegrationCredentials
                .FirstOrDefaultAsync(x => x.Provider == provider && x.IsActive);

            if (credentials == null)
                throw new Exception($"{provider} credentials not configured.");

            return _secretProtector.Unprotect(credentials.Value);
        }

        public async Task SaveCredentialAsync(IntegrationCredential credential)
        {
            credential.Value = _secretProtector.Protect(credential.Value);
            await _dbContext.IntegrationCredentials.AddAsync(credential);
            await _dbContext.SaveChangesAsync();
        }
    }
}
